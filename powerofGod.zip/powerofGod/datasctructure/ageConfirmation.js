function confirmAge(){
    let min_age=18
    let max_age=45
    let days_after_interview=30
    let days
}
