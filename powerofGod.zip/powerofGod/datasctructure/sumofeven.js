function sumOfEven(){
    let arr=[1, 2, 3, 4, 5, 6, 7, 8]
    let sum=0;
    arr.map((number)=>{
        if(number %2 ==0 ){
           sum=sum+number
        }
    })
    // for(let i =0; i<=arr.length; i++){
    //     if(i%2==0){
    //         sum  = sum +  i
    //     }
    // }
    console.log("Answer "+ sum)

}

sumOfEven()