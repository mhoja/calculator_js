function sumOfOdd(){
    let arr=[1, 2, 3, 4, 5, 6, 7, 8]
    let sum=0;
    for(let i =0; i<=arr.length; i++){
        if(i%2==1 || i==1){
            sum  = sum +  i
        }
    }
    console.log("sum of Even number "+ sum)
}

sumOfOdd()