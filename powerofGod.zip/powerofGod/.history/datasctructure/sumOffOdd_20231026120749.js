// function sumOfOdd(){
//     let arr=[1, 2, 3, 4, 5, 6, 7, 8]
//     let sum=0;
//     for(let i =0; i<=arr.length; i++){
//         if(i%2==1 || i==1){
//             sum  = sum +  i
//         }
//     }
//     console.log("sum of Even number "+ sum)
// }

// sumOfOdd()



<html>
<script>
     function performAction(action){
        // let name = document.getElementById("name").value;
        // let email= document.getElementById("email").value;

        let endpoint;
        let method;
        switch (action) {
            case 'create':
                method="POST";
                endpoint="/api/v1/create";
                break;
            case 'read':
                method="GET";
                endpoint="/api/v1/read";
                break;    
        
            default:
                break;
        }

     }

</script>
</html>

