function sumOfOdd(){
    let arr=[1, 2, 3, 4, 5, 6, 7, 8]
    let sum=0;
    for(let i =0; i<=arr.length; i++){
        if(i%2==1 || i==1){
            sum  = sum +  i
        }
    }
    console.log("sum of Even number "+ sum)
}

sumOfOdd()




PORT=3333
HOST=0.0.0.0
NODE_ENV=development

APP_KEY=r_20CcDi3YvuqLXMpUvaeNjv2CZriXRK
DRIVE_DISK=local
DB_CONNECTION=pg
PG_HOST=13.246.137.81
# PG_HOST=13.245.191.202

PG_PORT=5432
PG_USER=bbtz_appadmin
PG_PASSWORD=yX4WelwXHQ13gqgJbQzB
PG_DB_NAME=bbtz_dboard_db