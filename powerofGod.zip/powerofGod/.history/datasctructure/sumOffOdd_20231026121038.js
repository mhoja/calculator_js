// function sumOfOdd(){
//     let arr=[1, 2, 3, 4, 5, 6, 7, 8]
//     let sum=0;
//     for(let i =0; i<=arr.length; i++){
//         if(i%2==1 || i==1){
//             sum  = sum +  i
//         }
//     }
//     console.log("sum of Even number "+ sum)
// }

// sumOfOdd()



<html>
    <body>
        <script>
        function performAction(action) {
            const name = document.getElementById("name").value;
            const email = document.getElementById("email").value;
            const salary = document.getElementById("salary").value;

            let endpoint;
            let method;

            switch (action) {
                case 'create':
                    endpoint = 'http://127.0.0.1:3300/api/v1/employee';
                    method = 'POST';
                    break;
                case 'read':
                    endpoint = 'http://127.0.0.1:3300/api/v1/employees';
                    method = 'GET';
                    break;
                case 'update':
                    endpoint = 'http://127.0.0.1:3300/api/v1/employee';
                    method = 'PUT';
                    break;
                case 'delete':
                    endpoint = 'http://127.0.0.1:3300/api/v1/employee';
                    method = 'DELETE';
                    break;
                default:
                    return;
            }

            let requestData;
            if (action === 'create' || action === 'update') {
                requestData = { name, email, salary };
            }
            console.log("Data "+ JSON.stringify(requestData))
           
            fetch(endpoint, {
                method,
                headers: {
                    'Content-Type': 'application/json',
                },
                body: (action === 'create' || action === 'update') ? JSON.stringify(requestData) : null,
            })
                .then(response => response.json())
                .then(data => {
                    // Handle success
                    if (action === 'read') {
                        // Handle the response data for reading
                        const employeeList = document.getElementById("employeeList");
                        employeeList.innerHTML = ''; // Clear previous data
                        for (const employee of data.employees) {
                            console.log("DATA2 "+ JSON.stringify(data.employees))

                            const li = document.createElement("li");
                            li.textContent = `Name: ${employee.name}, Email: ${employee.email}, Salary: ${employee.salary}`;
                            employeeList.appendChild(li);
                        }
                    } else {
                        // Handle other CRUD actions
                        console.log(`Employee ${action}d:`, data);
                    }
                })
                .catch(error => {
                    // Handle error
                    console.error(`Error ${action}ing employee:`, error);
                });
        }
    </script>

    </body>

</html>

