from flask import Flask, request, jsonify

import psycopg2

app=Flask(__name__)


def db_conection():
    connection=psycopg2.connect(
        port=5432,
        host='13.246.137.81',
        user='bbtz_appadmin',
        password='yX4WelwXHQ13gqgJbQzB',
        dbname='bbtz_dboard_db'
    )
    return connection





if __name__=="__main__":
    app.run(debug=True, port=3300)