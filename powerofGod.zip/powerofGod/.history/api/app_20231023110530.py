from flask import Flask

app=Flask(__name__)







if __name=="__main__":
    app.run(debug=True, port=3300)