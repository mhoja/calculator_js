from flask import Flask, request, jsonify

import psycopg2

app=Flask(__name__)


def db_conection():
    connection=psycopg2.connect(
        port=5432,
        host='13.246.137.81',
        user='bbtz_appadmin',
        password='yX4WelwXHQ13gqgJbQzB',
        dbname='bbtz_dboard_db'
    )
    return connection


def addEmployees():
    cursor= db_conection().cursor()



@app.route('/api/v1/employees', methods=['GET'])
def getEmployees():
    db_conn=db_conection()
    cursor=db_conn.cursor()
    query=" SELECT id,name,email, salary from tt_employees "
    cursor.execute(query)
    employees=cursor.fetchall()
    employee_list=[]
    for emp in employees:
        emp_object={
            "id": emp[0],
            "name":emp[1],
            "email":emp[2],
            "salary":emp[3]
        }
        employee_list.append(emp_object)
    cursor.close()
    db_conn.close()    
    return jsonify({"employees": employee_list})    



if __name__=="__main__":
    app.run(debug=True, port=3300)