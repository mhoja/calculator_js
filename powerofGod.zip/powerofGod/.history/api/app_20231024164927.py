from flask import Flask, request, jsonify
from flask_cors import CORS

import psycopg2

app=Flask(__name__)


def db_conection():
    connection=psycopg2.connect(
        port=5432,
        host='13.246.137.81',
        user='bbtz_appadmin',
        password='yX4WelwXHQ13gqgJbQzB',
        dbname='bbtz_dboard_db'
    )
    return connection

CORS(app, resources={r"/api/*": {"origins": "*"}})

@app.route('/api/v1/employee', methods=['POST'])
def addEmployees():
    db_conn = db_conection()
    cursor = db_conn.cursor()
    data=request.json
    print("Data================= "+ str(data))
    query= "INSERT INTO tt_employees(name, email, salary) VALUES (%s, %s, %s) "
    cursor.execute(query,(data['name'], data['email'], data['salary']))
    db_conn.commit()
    cursor.close()
    db_conn.close()
    return jsonify({"message": "Success"})
    



@app.route('/api/v1/employees', methods=['GET'])
def getEmployees():
    db_conn=db_conection()
    cursor=db_conn.cursor()
    query=" SELECT id,name,email, salary from tt_employees "
    cursor.execute(query)
    employees=cursor.fetchall()
    employee_list=[]
    for emp in employees:
        emp_object={
            "id": emp[0],
            "name":emp[1],
            "email":emp[2],
            "salary":emp[3]
        }
        employee_list.append(emp_object)
    cursor.close()
    db_conn.close()    
    return jsonify({"employees": employee_list})    



@app.route('/api/v1/employee/<int:id>', methods=['PUT'])
def updateEmployee(id):
    print("=================" + str(id))  # Convert id to a string
    if request.method == 'PUT':
        db_conn = db_conection()
        cursor = db_conn.cursor()
        data = request.json
        print("data " + str(data))  # Convert data to a string

        query = "UPDATE tt_employees SET email=%s, name=%s, salary=%s WHERE id=%s"
        cursor.execute(query, (data['email'], data['name'], data['salary'], id))
        db_conn.commit()
        cursor.close()
        db_conn.close()
        return jsonify({"Message": f"user {id} updated successfully!!"})
    else:
        return jsonify({"Error": "Invalid request method"})
    

@app.route('/api/v1/employee/<int:id>', methods=['DELETE'])   
def deleteEmployee(id):
    print("========== "+ str(id))
    if request.method =="DELETE":
        
        db_conn= db_conection()
        cursor=db_conn.cursor()
        query= " DELETE  FROM tt_employees WHERE id=%s "
        cursor.execute(query,(id,))
        db_conn.commit()
        cursor.close()
        db_conn.close()
        return jsonify({"Message": f"employee with id {id} deleted successfully.. "})    

        
    else:
        return jsonify({"Error": "Invalid request method "})    
       
    



if __name__=="__main__":
    app.run(debug=True, port=3300)