from flask import Flask, request, jsonify

from 

app=Flask(__name__)


def db_conection():
    connection=





if __name__=="__main__":
    app.run(debug=True, port=3300)